import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-testeira-nota-mental',
  templateUrl: './testeira-nota-mental.component.html',
  styleUrls: ['./testeira-nota-mental.component.css']
})
export class TesteiraNotaMentalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
